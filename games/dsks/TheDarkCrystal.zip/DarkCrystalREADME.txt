From the Creators

Dark Crystal is a game that originally was sent over two disks with code on each side. You can play this game in our emulator though but it requires an extra step.
1. Load the Dsk image as normal.
2. Load the second disk exactly like the first when the game prompts you, which is a .nib file (1B).
3. Play the game. You'll be prompted later for disks 3 and 4 (2A and 2B).

Thanks!